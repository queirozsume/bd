<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bem-vindo (ou não)</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>
</head>
<body class="bg-dark text-center">
    <div class="container mt-5">
        <?php
            include "conecta.php";
            //TESTAR INJECTION COM O CÓDIGO ABAIXO NO CAMPO USUÁRIO. NÃO É NECESSÁRIO PREENCHER CAMPO SENHA.
            //' or 1=1; select * from usuario;#
            $usuario = $_POST['usuario'];
            $senha = $_POST['senha'];
            $query = "select * from usuario where usuario='$usuario' && senha='$senha'";
            //echo "<p class='text-white'>".$query."</p>";
            $mysqli->multi_query($query);
            do {
                if ($result = $mysqli->store_result()) {
                    $colunas=mysqli_num_fields($result);
                    while ($row = $result->fetch_row()) {
                        echo "<p class='text-white'>";
                        for($i = 0; $i < $colunas; $i++){
                            echo $row[$i]." ";
                        }
                        echo "</p>";
                        echo "<script>document.getElementsByTagName('p')[0].innerHTML = '';</script>";
                        
                    }
                    
                    if($result->num_rows < 1){
                        echo "<p class='text-danger'>Usuário ou senha incorretos!</p>";
                    } else {
                        echo "<p class='text-success'>Logado corretamente!</p>";
                    }
                    
                } 
                if ($mysqli->more_results()) {
                    echo "\n-----------------\n";
                }
            } while ($mysqli->next_result());

            $mysqli -> close(); 
        ?>
    </div>
</body>
</html>