<?php
    $mysqli = new mysqli('localhost', 'root', 'root', 'projeto'); //caso esteja usando porta diferente de 3306, acrescentar
    if ($mysqli -> connect_errno) {
        echo "Falha na conexão MySQL: " . $mysqli -> connect_error;
        exit();
    }
?>