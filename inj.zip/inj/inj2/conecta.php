<?php
    $mysqli = new mysqli('localhost', 'root', '', 'projeto');
    if ($mysqli -> connect_errno) {
        echo "<p class='text-danger'>Falha na conexão MySQL: " . $mysqli -> connect_error."</p>";
        exit();
    }
?>
