<?php
    $mysqli = new mysqli('localhost', 'AQUI_SEU_USUARIO_MYSQL', 'AQUI_SUA_SENHA_MYSQL', 'projeto'); //caso esteja usando porta diferente de 3306, acrescentar 
    if ($mysqli -> connect_errno) {
        echo "Falha na conexão MySQL: " . $mysqli -> connect_error;
        exit();
    }
?>
