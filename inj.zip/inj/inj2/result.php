<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>
</head>
<body class="bg-dark text-white text-center">
    <div class="container mt-5">
        <?php
            //TIPO 1 - BUSCAR NA TABELA ACTOR. ID, FIRST_NAME, LAST_NAME
            //TIPO 2 - BUSCAR NA TABELA ADDRESS. ADDRESS_ID, ADDRESS, DISTRICT, CITY_ID
            include "conecta.php";
            if($_GET['tipo']=="1"){
                if(isset($_GET['actor_id'])){
                    $actor_id = $_GET['actor_id'];
                }
                if(isset($_GET['first_name'])){
                    $first_name = $_GET['first_name'];
                }
                if(isset($_GET['last_name'])){
                    $last_name = $_GET['last_name'];
                }
                if(!isset($actor_id)&&!isset($first_name)&&isset($last_name)){
                    $query = "select actor_id, first_name, last_name from actor where last_name='$last_name'";
                } else if(!isset($actor_id)&&isset($first_name)&&!isset($last_name)){
                    $query = "select actor_id, first_name, last_name from actor where first_name='$first_name'";
                } else if(!isset($actor_id)&&isset($first_name)&&isset($last_name)){
                    $query = "select actor_id, first_name, last_name from actor where first_name='$first_name' and last_name='$last_name'";
                } else if(isset($actor_id)&&!isset($first_name)&&!isset($last_name)){
                    $query = "select actor_id, first_name, last_name from actor where actor_id='$actor_id'";
                } else if(isset($actor_id)&&!isset($first_name)&&isset($last_name)){
                    $query = "select actor_id, first_name, last_name from actor where actor_id='$actor_id' and last_name='$last_name'";
                } else if(isset($actor_id)&&isset($first_name)&&!isset($last_name)){
                    $query = "select actor_id, first_name, last_name from actor where actor_id='$actor_id' and first_name='$first_name'";
                } else if(isset($actor_id)&&isset($first_name)&&isset($last_name)){
                    $query = "select actor_id, first_name, last_name from actor where actor_id='$actor_id' and first_name='$first_name' and last_name='$last_name'";
                } else if(!isset($actor_id)&&!isset($first_name)&&!isset($last_name)){
                    $query = "select actor_id, first_name, last_name from actor";
                }
                
                //echo $query;
                $mysqli->multi_query($query);
                do {
                    if ($result = $mysqli->store_result()) {
                        while ($row = $result->fetch_row()) {
                            echo "<p class='text-white'>".$row[0]." ".$row[1]." ".$row[2]."</p>";
                            //echo "<script>document.getElementsByTagName('p')[0].innerHTML = '';</script>";
                        }
                    }
                    if ($mysqli->more_results()) {
                        echo "\n-----------------\n";
                    }
                } while ($mysqli->next_result());

                $mysqli -> close(); 
            }
            if($_GET['tipo']=="2"){
                if(isset($_GET['address_id'])){
                    $address_id = $_GET['address_id'];
                }
                if(isset($_GET['district'])){
                    $district = $_GET['district'];
                }
                if(isset($_GET['city_id'])){
                    $city_id = $_GET['city_id'];
                }
                if(!isset($address_id)&&!isset($district)&&isset($city_id)){
                    $query = "select address_id, address, district, city_id from address where city_id=$city_id";
                } else if(!isset($address_id)&&isset($district)&&!isset($city_id)){
                    $query = "select address_id, address, district, city_id from address where district='$district'";
                } else if(!isset($address_id)&&isset($district)&&isset($city_id)){
                    $query = "select address_id, address, district, city_id from address where district='$district' and city_id=$city_id";
                } else if(isset($address_id)&&!isset($district)&&!isset($city_id)){
                    $query = "select address_id, address, district, city_id from address where address_id=$address_id";
                } else if(isset($address_id)&&!isset($district)&&isset($city_id)){
                    $query = "select address_id, address, district, city_id from address where address_id=$address_id and city_id=$city_id";
                } else if(isset($address_id)&&isset($district)&&!isset($city_id)){
                    $query = "select address_id, address, district, city_id from address where address_id=$address_id and district='$district'";
                } else if(isset($address_id)&&isset($district)&&isset($city_id)){
                    $query = "select address_id, address, district, city_id from address where address_id=$address_id and district='$district' and city_id=$city_id";
                } else if(!isset($address_id)&&!isset($district)&&!isset($city_id)){
                    $query = "select address_id, address, district, city_id from address";
                }
                
                //echo $query;
                $mysqli->multi_query($query);
                do {
                    if ($result = $mysqli->store_result()) {
                        $colunas=mysqli_num_fields($result);
                        while ($row = $result->fetch_row()) {
                            echo "<p class='text-white'>";
                            for($i = 0; $i < $colunas; $i++){
                                echo $row[$i]." ";
                            }
                            echo "</p>";
                            //echo "<script>document.getElementsByTagName('p')[0].innerHTML = '';</script>";
                        }
                    }
                    if ($mysqli->more_results()) {
                        echo "\n-----------------\n";
                    }
                } while ($mysqli->next_result());

                $mysqli -> close();                 
            }
        ?>
    </div>
</body>
</html>